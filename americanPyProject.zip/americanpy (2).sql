-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Gegenereerd op: 15 okt 2015 om 16:55
-- Serverversie: 5.6.26
-- PHP-versie: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `americanpy`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `aanbieders`
--

CREATE TABLE IF NOT EXISTS `aanbieders` (
  `id` int(5) NOT NULL,
  `naam` varchar(40) NOT NULL,
  `achternaam` varchar(60) NOT NULL,
  `film` varchar(255) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1005 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `aanbieders`
--

INSERT INTO `aanbieders` (`id`, `naam`, `achternaam`, `film`, `username`, `password`) VALUES
(1000, 'David', 'Meulenbeld', '', 'David', '1234'),
(1001, 'Mitchell ', 'Bloemink', '', 'Mitchell', '2345'),
(1002, 'Dennis', 'van Valderen', 'The Hours', 'Dennis', '3456'),
(1003, 'Tarik', 'Otman', 'Rescue Dawn', 'Tarik', '4567'),
(1004, 'Rik', 'Ruttenberg', '', 'Rik', '5678');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `bezoekers`
--

CREATE TABLE IF NOT EXISTS `bezoekers` (
  `id` int(5) NOT NULL,
  `naam` varchar(32) NOT NULL,
  `email` varchar(32) NOT NULL,
  `aanbiederid` int(5) NOT NULL,
  `uniekecode` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1008 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `bezoekers`
--

INSERT INTO `bezoekers` (`id`, `naam`, `email`, `aanbiederid`, `uniekecode`) VALUES
(1000, 'pietje', 'pietje@mail.com', 1004, '5415hh145h425kl'),
(1001, 'jan', 'jan@versteeg.nl', 1002, '252436hhk6236'),
(1004, 'Rishi', 'rishi@gmail.com', 1002, 'UlvklWkh#Krxuv'),
(1005, 'janwillemPauwtje', 'pauw@gmail.com', 1003, 'mdqzloohpSdxzwmhUhvf'),
(1006, 'DenDen', 'denden@gmail.com', 1002, 'GhqGhqWkh#Krxuv'),
(1007, 'DenDenwatet', 'dennnnis@gmail.com', 1002, 'GhqGhqzdwhwWkh#Krxuv');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `films`
--

CREATE TABLE IF NOT EXISTS `films` (
  `id` int(5) NOT NULL,
  `titel` varchar(100) NOT NULL,
  `cover` varchar(255) NOT NULL,
  `synopsis` varchar(255) NOT NULL,
  `genres` varchar(255) NOT NULL,
  `filmduur` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `zender` varchar(255) NOT NULL,
  `rating` varchar(255) NOT NULL,
  `starttijd` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `films`
--

INSERT INTO `films` (`id`, `titel`, `cover`, `synopsis`, `genres`, `filmduur`, `link`, `zender`, `rating`, `starttijd`) VALUES
(1, 'One for the Money', 'http://www.filmtotaal.nl/images/covers/nzvwzsz3m8.jpg', 'In One for the Money gaat de net ontslagen Stephanie Plum uit wanhoop werken voor het tweederangs schuldsaneringsbureau van haar neef. Ze komt in bizarre en komische situaties terecht wanneer ze Joe Morelli, de man die vroeger haar hart heeft gebroken, mo', 'Actie:Komedie:Misdaad:Thriller', '91', 'http://www.filmtotaal.nl/film.php?id=20947', 'NET5', '5.3', '1444933800'),
(2, 'The Living Daylights', 'http://www.filmtotaal.nl/images/covers/kdlqdvsqiy.jpg', 'James Bond moet zien te voorkomen dat een onbekende scherpschutter de KGB-agent Georgi Koskov van het leven berooft. De mysterieuze schutter blijkt de aantrekkelijke celliste Kara Malovy te zijn. Generaal Koskov vertelt dat de KGB van plan is om moordaans', 'Actie:Avontuur:Muziek:Thriller', '130', 'http://www.filmtotaal.nl/film.php?id=1851', 'RTL7', '6.7', '1444933800'),
(3, 'The Hours', 'http://www.filmtotaal.nl/images/covers/jl28okuvzp.jpg', 'De zwangere Laura Brown plant in 1949 een feest voor haar echtgenoot, en leest tegelijkertijd de roman Mrs. Dalloway van Virginia Woolf. Clarissa Vaughn, een vrouw die in het heden leeft, organiseert een feestje voor haar vriend Richard, een beroemde aute', 'Drama', '114', 'http://www.filmtotaal.nl/film.php?id=7409', 'RTL8', '7.6', '1444933800'),
(4, 'Wild Hogs', 'http://www.filmtotaal.nl/images/covers/1gdlkxq2p2.jpg', 'Vier vrienden in een midlifecrisis, Doug (Tim Allen), Woody (John Travolta), Bobby (Martin Lawrence) en Dudley (William H. Macy), besluiten hun geroutineerde en doorsnee leven een andere draai te geven en beginnen aan een freewheeling trip op de motor. Na', 'Actie:Avontuur:Komedie', '100', 'http://www.filmtotaal.nl/film.php?id=241', 'Veronica', '5.9', '1444933800'),
(5, 'Rescue Dawn', 'http://www.filmtotaal.nl/images/covers/ppzx3bmnr0.jpg', 'RESCUE DAWN is het tweede eerbetoon van Herzog aan de onverwoestbare overlevingsdrang van de tijdens Vietnamoorlog neergehaalde piloot Dieter Dengler die Vietcong-gevangenschap en ondoordringbare jungle moet overwinnen. &lt;br&gt;', 'Actie:Avontuur:Drama:Oorlog', '126', 'http://www.filmtotaal.nl/film.php?id=13301', 'SBS9', '7.4', '1444933800'),
(6, 'Fils de l''&eacute;picier, Le', 'http://www.filmtotaal.nl/images/covers/25ser3wocl.jpg', 'Het is hartje zomer wanneer de dertigjarige Antoine noodgedwongen de stad verruilt voor de rustieke omgeving van zijn geboortedorp. Zijn vader ligt in het ziekenhuis en hoewel Antoine een grondige hekel aan hem heeft, neemt hij toch (vooral voor zijn moed', 'Drama', '96', 'http://www.filmtotaal.nl/film.php?id=14061', 'TV5', '7.1', '1444935720'),
(7, 'One for the Money', 'http://www.filmtotaal.nl/images/covers/nzvwzsz3m8.jpg', 'In One for the Money gaat de net ontslagen Stephanie Plum uit wanhoop werken voor het tweederangs schuldsaneringsbureau van haar neef. Ze komt in bizarre en komische situaties terecht wanneer ze Joe Morelli, de man die vroeger haar hart heeft gebroken, mo', 'Actie:Komedie:Misdaad:Thriller', '91', 'http://www.filmtotaal.nl/film.php?id=20947', 'NET5', '5.3', '1444933800'),
(8, 'The Living Daylights', 'http://www.filmtotaal.nl/images/covers/kdlqdvsqiy.jpg', 'James Bond moet zien te voorkomen dat een onbekende scherpschutter de KGB-agent Georgi Koskov van het leven berooft. De mysterieuze schutter blijkt de aantrekkelijke celliste Kara Malovy te zijn. Generaal Koskov vertelt dat de KGB van plan is om moordaans', 'Actie:Avontuur:Muziek:Thriller', '130', 'http://www.filmtotaal.nl/film.php?id=1851', 'RTL7', '6.7', '1444933800'),
(9, 'The Hours', 'http://www.filmtotaal.nl/images/covers/jl28okuvzp.jpg', 'De zwangere Laura Brown plant in 1949 een feest voor haar echtgenoot, en leest tegelijkertijd de roman Mrs. Dalloway van Virginia Woolf. Clarissa Vaughn, een vrouw die in het heden leeft, organiseert een feestje voor haar vriend Richard, een beroemde aute', 'Drama', '114', 'http://www.filmtotaal.nl/film.php?id=7409', 'RTL8', '7.6', '1444933800'),
(10, 'Wild Hogs', 'http://www.filmtotaal.nl/images/covers/1gdlkxq2p2.jpg', 'Vier vrienden in een midlifecrisis, Doug (Tim Allen), Woody (John Travolta), Bobby (Martin Lawrence) en Dudley (William H. Macy), besluiten hun geroutineerde en doorsnee leven een andere draai te geven en beginnen aan een freewheeling trip op de motor. Na', 'Actie:Avontuur:Komedie', '100', 'http://www.filmtotaal.nl/film.php?id=241', 'Veronica', '5.9', '1444933800'),
(11, 'Rescue Dawn', 'http://www.filmtotaal.nl/images/covers/ppzx3bmnr0.jpg', 'RESCUE DAWN is het tweede eerbetoon van Herzog aan de onverwoestbare overlevingsdrang van de tijdens Vietnamoorlog neergehaalde piloot Dieter Dengler die Vietcong-gevangenschap en ondoordringbare jungle moet overwinnen. &lt;br&gt;', 'Actie:Avontuur:Drama:Oorlog', '126', 'http://www.filmtotaal.nl/film.php?id=13301', 'SBS9', '7.4', '1444933800'),
(12, 'Fils de l''&eacute;picier, Le', 'http://www.filmtotaal.nl/images/covers/25ser3wocl.jpg', 'Het is hartje zomer wanneer de dertigjarige Antoine noodgedwongen de stad verruilt voor de rustieke omgeving van zijn geboortedorp. Zijn vader ligt in het ziekenhuis en hoewel Antoine een grondige hekel aan hem heeft, neemt hij toch (vooral voor zijn moed', 'Drama', '96', 'http://www.filmtotaal.nl/film.php?id=14061', 'TV5', '7.1', '1444935720'),
(13, 'One for the Money', 'http://www.filmtotaal.nl/images/covers/nzvwzsz3m8.jpg', 'In One for the Money gaat de net ontslagen Stephanie Plum uit wanhoop werken voor het tweederangs schuldsaneringsbureau van haar neef. Ze komt in bizarre en komische situaties terecht wanneer ze Joe Morelli, de man die vroeger haar hart heeft gebroken, mo', 'Actie:Komedie:Misdaad:Thriller', '91', 'http://www.filmtotaal.nl/film.php?id=20947', 'NET5', '5.3', '1444933800'),
(14, 'The Living Daylights', 'http://www.filmtotaal.nl/images/covers/kdlqdvsqiy.jpg', 'James Bond moet zien te voorkomen dat een onbekende scherpschutter de KGB-agent Georgi Koskov van het leven berooft. De mysterieuze schutter blijkt de aantrekkelijke celliste Kara Malovy te zijn. Generaal Koskov vertelt dat de KGB van plan is om moordaans', 'Actie:Avontuur:Muziek:Thriller', '130', 'http://www.filmtotaal.nl/film.php?id=1851', 'RTL7', '6.7', '1444933800'),
(15, 'The Hours', 'http://www.filmtotaal.nl/images/covers/jl28okuvzp.jpg', 'De zwangere Laura Brown plant in 1949 een feest voor haar echtgenoot, en leest tegelijkertijd de roman Mrs. Dalloway van Virginia Woolf. Clarissa Vaughn, een vrouw die in het heden leeft, organiseert een feestje voor haar vriend Richard, een beroemde aute', 'Drama', '114', 'http://www.filmtotaal.nl/film.php?id=7409', 'RTL8', '7.6', '1444933800'),
(16, 'Wild Hogs', 'http://www.filmtotaal.nl/images/covers/1gdlkxq2p2.jpg', 'Vier vrienden in een midlifecrisis, Doug (Tim Allen), Woody (John Travolta), Bobby (Martin Lawrence) en Dudley (William H. Macy), besluiten hun geroutineerde en doorsnee leven een andere draai te geven en beginnen aan een freewheeling trip op de motor. Na', 'Actie:Avontuur:Komedie', '100', 'http://www.filmtotaal.nl/film.php?id=241', 'Veronica', '5.9', '1444933800'),
(17, 'Rescue Dawn', 'http://www.filmtotaal.nl/images/covers/ppzx3bmnr0.jpg', 'RESCUE DAWN is het tweede eerbetoon van Herzog aan de onverwoestbare overlevingsdrang van de tijdens Vietnamoorlog neergehaalde piloot Dieter Dengler die Vietcong-gevangenschap en ondoordringbare jungle moet overwinnen. &lt;br&gt;', 'Actie:Avontuur:Drama:Oorlog', '126', 'http://www.filmtotaal.nl/film.php?id=13301', 'SBS9', '7.4', '1444933800'),
(18, 'Fils de l''&eacute;picier, Le', 'http://www.filmtotaal.nl/images/covers/25ser3wocl.jpg', 'Het is hartje zomer wanneer de dertigjarige Antoine noodgedwongen de stad verruilt voor de rustieke omgeving van zijn geboortedorp. Zijn vader ligt in het ziekenhuis en hoewel Antoine een grondige hekel aan hem heeft, neemt hij toch (vooral voor zijn moed', 'Drama', '96', 'http://www.filmtotaal.nl/film.php?id=14061', 'TV5', '7.1', '1444935720'),
(19, 'One for the Money', 'http://www.filmtotaal.nl/images/covers/nzvwzsz3m8.jpg', 'In One for the Money gaat de net ontslagen Stephanie Plum uit wanhoop werken voor het tweederangs schuldsaneringsbureau van haar neef. Ze komt in bizarre en komische situaties terecht wanneer ze Joe Morelli, de man die vroeger haar hart heeft gebroken, mo', 'Actie:Komedie:Misdaad:Thriller', '91', 'http://www.filmtotaal.nl/film.php?id=20947', 'NET5', '5.3', '1444933800'),
(20, 'The Living Daylights', 'http://www.filmtotaal.nl/images/covers/kdlqdvsqiy.jpg', 'James Bond moet zien te voorkomen dat een onbekende scherpschutter de KGB-agent Georgi Koskov van het leven berooft. De mysterieuze schutter blijkt de aantrekkelijke celliste Kara Malovy te zijn. Generaal Koskov vertelt dat de KGB van plan is om moordaans', 'Actie:Avontuur:Muziek:Thriller', '130', 'http://www.filmtotaal.nl/film.php?id=1851', 'RTL7', '6.7', '1444933800'),
(21, 'The Hours', 'http://www.filmtotaal.nl/images/covers/jl28okuvzp.jpg', 'De zwangere Laura Brown plant in 1949 een feest voor haar echtgenoot, en leest tegelijkertijd de roman Mrs. Dalloway van Virginia Woolf. Clarissa Vaughn, een vrouw die in het heden leeft, organiseert een feestje voor haar vriend Richard, een beroemde aute', 'Drama', '114', 'http://www.filmtotaal.nl/film.php?id=7409', 'RTL8', '7.6', '1444933800'),
(22, 'Wild Hogs', 'http://www.filmtotaal.nl/images/covers/1gdlkxq2p2.jpg', 'Vier vrienden in een midlifecrisis, Doug (Tim Allen), Woody (John Travolta), Bobby (Martin Lawrence) en Dudley (William H. Macy), besluiten hun geroutineerde en doorsnee leven een andere draai te geven en beginnen aan een freewheeling trip op de motor. Na', 'Actie:Avontuur:Komedie', '100', 'http://www.filmtotaal.nl/film.php?id=241', 'Veronica', '5.9', '1444933800'),
(23, 'Rescue Dawn', 'http://www.filmtotaal.nl/images/covers/ppzx3bmnr0.jpg', 'RESCUE DAWN is het tweede eerbetoon van Herzog aan de onverwoestbare overlevingsdrang van de tijdens Vietnamoorlog neergehaalde piloot Dieter Dengler die Vietcong-gevangenschap en ondoordringbare jungle moet overwinnen. &lt;br&gt;', 'Actie:Avontuur:Drama:Oorlog', '126', 'http://www.filmtotaal.nl/film.php?id=13301', 'SBS9', '7.4', '1444933800'),
(24, 'Fils de l''&eacute;picier, Le', 'http://www.filmtotaal.nl/images/covers/25ser3wocl.jpg', 'Het is hartje zomer wanneer de dertigjarige Antoine noodgedwongen de stad verruilt voor de rustieke omgeving van zijn geboortedorp. Zijn vader ligt in het ziekenhuis en hoewel Antoine een grondige hekel aan hem heeft, neemt hij toch (vooral voor zijn moed', 'Drama', '96', 'http://www.filmtotaal.nl/film.php?id=14061', 'TV5', '7.1', '1444935720'),
(25, 'One for the Money', 'http://www.filmtotaal.nl/images/covers/nzvwzsz3m8.jpg', 'In One for the Money gaat de net ontslagen Stephanie Plum uit wanhoop werken voor het tweederangs schuldsaneringsbureau van haar neef. Ze komt in bizarre en komische situaties terecht wanneer ze Joe Morelli, de man die vroeger haar hart heeft gebroken, mo', 'Actie:Komedie:Misdaad:Thriller', '91', 'http://www.filmtotaal.nl/film.php?id=20947', 'NET5', '5.3', '1444933800'),
(26, 'The Living Daylights', 'http://www.filmtotaal.nl/images/covers/kdlqdvsqiy.jpg', 'James Bond moet zien te voorkomen dat een onbekende scherpschutter de KGB-agent Georgi Koskov van het leven berooft. De mysterieuze schutter blijkt de aantrekkelijke celliste Kara Malovy te zijn. Generaal Koskov vertelt dat de KGB van plan is om moordaans', 'Actie:Avontuur:Muziek:Thriller', '130', 'http://www.filmtotaal.nl/film.php?id=1851', 'RTL7', '6.7', '1444933800'),
(27, 'The Hours', 'http://www.filmtotaal.nl/images/covers/jl28okuvzp.jpg', 'De zwangere Laura Brown plant in 1949 een feest voor haar echtgenoot, en leest tegelijkertijd de roman Mrs. Dalloway van Virginia Woolf. Clarissa Vaughn, een vrouw die in het heden leeft, organiseert een feestje voor haar vriend Richard, een beroemde aute', 'Drama', '114', 'http://www.filmtotaal.nl/film.php?id=7409', 'RTL8', '7.6', '1444933800'),
(28, 'Wild Hogs', 'http://www.filmtotaal.nl/images/covers/1gdlkxq2p2.jpg', 'Vier vrienden in een midlifecrisis, Doug (Tim Allen), Woody (John Travolta), Bobby (Martin Lawrence) en Dudley (William H. Macy), besluiten hun geroutineerde en doorsnee leven een andere draai te geven en beginnen aan een freewheeling trip op de motor. Na', 'Actie:Avontuur:Komedie', '100', 'http://www.filmtotaal.nl/film.php?id=241', 'Veronica', '5.9', '1444933800'),
(29, 'Rescue Dawn', 'http://www.filmtotaal.nl/images/covers/ppzx3bmnr0.jpg', 'RESCUE DAWN is het tweede eerbetoon van Herzog aan de onverwoestbare overlevingsdrang van de tijdens Vietnamoorlog neergehaalde piloot Dieter Dengler die Vietcong-gevangenschap en ondoordringbare jungle moet overwinnen. &lt;br&gt;', 'Actie:Avontuur:Drama:Oorlog', '126', 'http://www.filmtotaal.nl/film.php?id=13301', 'SBS9', '7.4', '1444933800'),
(30, 'Fils de l''&eacute;picier, Le', 'http://www.filmtotaal.nl/images/covers/25ser3wocl.jpg', 'Het is hartje zomer wanneer de dertigjarige Antoine noodgedwongen de stad verruilt voor de rustieke omgeving van zijn geboortedorp. Zijn vader ligt in het ziekenhuis en hoewel Antoine een grondige hekel aan hem heeft, neemt hij toch (vooral voor zijn moed', 'Drama', '96', 'http://www.filmtotaal.nl/film.php?id=14061', 'TV5', '7.1', '1444935720'),
(31, 'One for the Money', 'http://www.filmtotaal.nl/images/covers/nzvwzsz3m8.jpg', 'In One for the Money gaat de net ontslagen Stephanie Plum uit wanhoop werken voor het tweederangs schuldsaneringsbureau van haar neef. Ze komt in bizarre en komische situaties terecht wanneer ze Joe Morelli, de man die vroeger haar hart heeft gebroken, mo', 'Actie:Komedie:Misdaad:Thriller', '91', 'http://www.filmtotaal.nl/film.php?id=20947', 'NET5', '5.3', '1444933800'),
(32, 'The Living Daylights', 'http://www.filmtotaal.nl/images/covers/kdlqdvsqiy.jpg', 'James Bond moet zien te voorkomen dat een onbekende scherpschutter de KGB-agent Georgi Koskov van het leven berooft. De mysterieuze schutter blijkt de aantrekkelijke celliste Kara Malovy te zijn. Generaal Koskov vertelt dat de KGB van plan is om moordaans', 'Actie:Avontuur:Muziek:Thriller', '130', 'http://www.filmtotaal.nl/film.php?id=1851', 'RTL7', '6.7', '1444933800'),
(33, 'The Hours', 'http://www.filmtotaal.nl/images/covers/jl28okuvzp.jpg', 'De zwangere Laura Brown plant in 1949 een feest voor haar echtgenoot, en leest tegelijkertijd de roman Mrs. Dalloway van Virginia Woolf. Clarissa Vaughn, een vrouw die in het heden leeft, organiseert een feestje voor haar vriend Richard, een beroemde aute', 'Drama', '114', 'http://www.filmtotaal.nl/film.php?id=7409', 'RTL8', '7.6', '1444933800'),
(34, 'Wild Hogs', 'http://www.filmtotaal.nl/images/covers/1gdlkxq2p2.jpg', 'Vier vrienden in een midlifecrisis, Doug (Tim Allen), Woody (John Travolta), Bobby (Martin Lawrence) en Dudley (William H. Macy), besluiten hun geroutineerde en doorsnee leven een andere draai te geven en beginnen aan een freewheeling trip op de motor. Na', 'Actie:Avontuur:Komedie', '100', 'http://www.filmtotaal.nl/film.php?id=241', 'Veronica', '5.9', '1444933800'),
(35, 'Rescue Dawn', 'http://www.filmtotaal.nl/images/covers/ppzx3bmnr0.jpg', 'RESCUE DAWN is het tweede eerbetoon van Herzog aan de onverwoestbare overlevingsdrang van de tijdens Vietnamoorlog neergehaalde piloot Dieter Dengler die Vietcong-gevangenschap en ondoordringbare jungle moet overwinnen. &lt;br&gt;', 'Actie:Avontuur:Drama:Oorlog', '126', 'http://www.filmtotaal.nl/film.php?id=13301', 'SBS9', '7.4', '1444933800'),
(36, 'Fils de l''&eacute;picier, Le', 'http://www.filmtotaal.nl/images/covers/25ser3wocl.jpg', 'Het is hartje zomer wanneer de dertigjarige Antoine noodgedwongen de stad verruilt voor de rustieke omgeving van zijn geboortedorp. Zijn vader ligt in het ziekenhuis en hoewel Antoine een grondige hekel aan hem heeft, neemt hij toch (vooral voor zijn moed', 'Drama', '96', 'http://www.filmtotaal.nl/film.php?id=14061', 'TV5', '7.1', '1444935720'),
(37, 'One for the Money', 'http://www.filmtotaal.nl/images/covers/nzvwzsz3m8.jpg', 'In One for the Money gaat de net ontslagen Stephanie Plum uit wanhoop werken voor het tweederangs schuldsaneringsbureau van haar neef. Ze komt in bizarre en komische situaties terecht wanneer ze Joe Morelli, de man die vroeger haar hart heeft gebroken, mo', 'Actie:Komedie:Misdaad:Thriller', '91', 'http://www.filmtotaal.nl/film.php?id=20947', 'NET5', '5.3', '1444933800'),
(38, 'The Living Daylights', 'http://www.filmtotaal.nl/images/covers/kdlqdvsqiy.jpg', 'James Bond moet zien te voorkomen dat een onbekende scherpschutter de KGB-agent Georgi Koskov van het leven berooft. De mysterieuze schutter blijkt de aantrekkelijke celliste Kara Malovy te zijn. Generaal Koskov vertelt dat de KGB van plan is om moordaans', 'Actie:Avontuur:Muziek:Thriller', '130', 'http://www.filmtotaal.nl/film.php?id=1851', 'RTL7', '6.7', '1444933800'),
(39, 'The Hours', 'http://www.filmtotaal.nl/images/covers/jl28okuvzp.jpg', 'De zwangere Laura Brown plant in 1949 een feest voor haar echtgenoot, en leest tegelijkertijd de roman Mrs. Dalloway van Virginia Woolf. Clarissa Vaughn, een vrouw die in het heden leeft, organiseert een feestje voor haar vriend Richard, een beroemde aute', 'Drama', '114', 'http://www.filmtotaal.nl/film.php?id=7409', 'RTL8', '7.6', '1444933800'),
(40, 'Wild Hogs', 'http://www.filmtotaal.nl/images/covers/1gdlkxq2p2.jpg', 'Vier vrienden in een midlifecrisis, Doug (Tim Allen), Woody (John Travolta), Bobby (Martin Lawrence) en Dudley (William H. Macy), besluiten hun geroutineerde en doorsnee leven een andere draai te geven en beginnen aan een freewheeling trip op de motor. Na', 'Actie:Avontuur:Komedie', '100', 'http://www.filmtotaal.nl/film.php?id=241', 'Veronica', '5.9', '1444933800'),
(41, 'Rescue Dawn', 'http://www.filmtotaal.nl/images/covers/ppzx3bmnr0.jpg', 'RESCUE DAWN is het tweede eerbetoon van Herzog aan de onverwoestbare overlevingsdrang van de tijdens Vietnamoorlog neergehaalde piloot Dieter Dengler die Vietcong-gevangenschap en ondoordringbare jungle moet overwinnen. &lt;br&gt;', 'Actie:Avontuur:Drama:Oorlog', '126', 'http://www.filmtotaal.nl/film.php?id=13301', 'SBS9', '7.4', '1444933800'),
(42, 'Fils de l''&eacute;picier, Le', 'http://www.filmtotaal.nl/images/covers/25ser3wocl.jpg', 'Het is hartje zomer wanneer de dertigjarige Antoine noodgedwongen de stad verruilt voor de rustieke omgeving van zijn geboortedorp. Zijn vader ligt in het ziekenhuis en hoewel Antoine een grondige hekel aan hem heeft, neemt hij toch (vooral voor zijn moed', 'Drama', '96', 'http://www.filmtotaal.nl/film.php?id=14061', 'TV5', '7.1', '1444935720'),
(43, 'One for the Money', 'http://www.filmtotaal.nl/images/covers/nzvwzsz3m8.jpg', 'In One for the Money gaat de net ontslagen Stephanie Plum uit wanhoop werken voor het tweederangs schuldsaneringsbureau van haar neef. Ze komt in bizarre en komische situaties terecht wanneer ze Joe Morelli, de man die vroeger haar hart heeft gebroken, mo', 'Actie:Komedie:Misdaad:Thriller', '91', 'http://www.filmtotaal.nl/film.php?id=20947', 'NET5', '5.3', '1444933800'),
(44, 'The Living Daylights', 'http://www.filmtotaal.nl/images/covers/kdlqdvsqiy.jpg', 'James Bond moet zien te voorkomen dat een onbekende scherpschutter de KGB-agent Georgi Koskov van het leven berooft. De mysterieuze schutter blijkt de aantrekkelijke celliste Kara Malovy te zijn. Generaal Koskov vertelt dat de KGB van plan is om moordaans', 'Actie:Avontuur:Muziek:Thriller', '130', 'http://www.filmtotaal.nl/film.php?id=1851', 'RTL7', '6.7', '1444933800'),
(45, 'The Hours', 'http://www.filmtotaal.nl/images/covers/jl28okuvzp.jpg', 'De zwangere Laura Brown plant in 1949 een feest voor haar echtgenoot, en leest tegelijkertijd de roman Mrs. Dalloway van Virginia Woolf. Clarissa Vaughn, een vrouw die in het heden leeft, organiseert een feestje voor haar vriend Richard, een beroemde aute', 'Drama', '114', 'http://www.filmtotaal.nl/film.php?id=7409', 'RTL8', '7.6', '1444933800'),
(46, 'Wild Hogs', 'http://www.filmtotaal.nl/images/covers/1gdlkxq2p2.jpg', 'Vier vrienden in een midlifecrisis, Doug (Tim Allen), Woody (John Travolta), Bobby (Martin Lawrence) en Dudley (William H. Macy), besluiten hun geroutineerde en doorsnee leven een andere draai te geven en beginnen aan een freewheeling trip op de motor. Na', 'Actie:Avontuur:Komedie', '100', 'http://www.filmtotaal.nl/film.php?id=241', 'Veronica', '5.9', '1444933800'),
(47, 'Rescue Dawn', 'http://www.filmtotaal.nl/images/covers/ppzx3bmnr0.jpg', 'RESCUE DAWN is het tweede eerbetoon van Herzog aan de onverwoestbare overlevingsdrang van de tijdens Vietnamoorlog neergehaalde piloot Dieter Dengler die Vietcong-gevangenschap en ondoordringbare jungle moet overwinnen. &lt;br&gt;', 'Actie:Avontuur:Drama:Oorlog', '126', 'http://www.filmtotaal.nl/film.php?id=13301', 'SBS9', '7.4', '1444933800'),
(48, 'Fils de l''&eacute;picier, Le', 'http://www.filmtotaal.nl/images/covers/25ser3wocl.jpg', 'Het is hartje zomer wanneer de dertigjarige Antoine noodgedwongen de stad verruilt voor de rustieke omgeving van zijn geboortedorp. Zijn vader ligt in het ziekenhuis en hoewel Antoine een grondige hekel aan hem heeft, neemt hij toch (vooral voor zijn moed', 'Drama', '96', 'http://www.filmtotaal.nl/film.php?id=14061', 'TV5', '7.1', '1444935720'),
(49, 'One for the Money', 'http://www.filmtotaal.nl/images/covers/nzvwzsz3m8.jpg', 'In One for the Money gaat de net ontslagen Stephanie Plum uit wanhoop werken voor het tweederangs schuldsaneringsbureau van haar neef. Ze komt in bizarre en komische situaties terecht wanneer ze Joe Morelli, de man die vroeger haar hart heeft gebroken, mo', 'Actie:Komedie:Misdaad:Thriller', '91', 'http://www.filmtotaal.nl/film.php?id=20947', 'NET5', '5.3', '1444933800'),
(50, 'The Living Daylights', 'http://www.filmtotaal.nl/images/covers/kdlqdvsqiy.jpg', 'James Bond moet zien te voorkomen dat een onbekende scherpschutter de KGB-agent Georgi Koskov van het leven berooft. De mysterieuze schutter blijkt de aantrekkelijke celliste Kara Malovy te zijn. Generaal Koskov vertelt dat de KGB van plan is om moordaans', 'Actie:Avontuur:Muziek:Thriller', '130', 'http://www.filmtotaal.nl/film.php?id=1851', 'RTL7', '6.7', '1444933800'),
(51, 'The Hours', 'http://www.filmtotaal.nl/images/covers/jl28okuvzp.jpg', 'De zwangere Laura Brown plant in 1949 een feest voor haar echtgenoot, en leest tegelijkertijd de roman Mrs. Dalloway van Virginia Woolf. Clarissa Vaughn, een vrouw die in het heden leeft, organiseert een feestje voor haar vriend Richard, een beroemde aute', 'Drama', '114', 'http://www.filmtotaal.nl/film.php?id=7409', 'RTL8', '7.6', '1444933800'),
(52, 'Wild Hogs', 'http://www.filmtotaal.nl/images/covers/1gdlkxq2p2.jpg', 'Vier vrienden in een midlifecrisis, Doug (Tim Allen), Woody (John Travolta), Bobby (Martin Lawrence) en Dudley (William H. Macy), besluiten hun geroutineerde en doorsnee leven een andere draai te geven en beginnen aan een freewheeling trip op de motor. Na', 'Actie:Avontuur:Komedie', '100', 'http://www.filmtotaal.nl/film.php?id=241', 'Veronica', '5.9', '1444933800'),
(53, 'Rescue Dawn', 'http://www.filmtotaal.nl/images/covers/ppzx3bmnr0.jpg', 'RESCUE DAWN is het tweede eerbetoon van Herzog aan de onverwoestbare overlevingsdrang van de tijdens Vietnamoorlog neergehaalde piloot Dieter Dengler die Vietcong-gevangenschap en ondoordringbare jungle moet overwinnen. &lt;br&gt;', 'Actie:Avontuur:Drama:Oorlog', '126', 'http://www.filmtotaal.nl/film.php?id=13301', 'SBS9', '7.4', '1444933800'),
(54, 'Fils de l''&eacute;picier, Le', 'http://www.filmtotaal.nl/images/covers/25ser3wocl.jpg', 'Het is hartje zomer wanneer de dertigjarige Antoine noodgedwongen de stad verruilt voor de rustieke omgeving van zijn geboortedorp. Zijn vader ligt in het ziekenhuis en hoewel Antoine een grondige hekel aan hem heeft, neemt hij toch (vooral voor zijn moed', 'Drama', '96', 'http://www.filmtotaal.nl/film.php?id=14061', 'TV5', '7.1', '1444935720'),
(55, 'One for the Money', 'http://www.filmtotaal.nl/images/covers/nzvwzsz3m8.jpg', 'In One for the Money gaat de net ontslagen Stephanie Plum uit wanhoop werken voor het tweederangs schuldsaneringsbureau van haar neef. Ze komt in bizarre en komische situaties terecht wanneer ze Joe Morelli, de man die vroeger haar hart heeft gebroken, mo', 'Actie:Komedie:Misdaad:Thriller', '91', 'http://www.filmtotaal.nl/film.php?id=20947', 'NET5', '5.3', '1444933800'),
(56, 'The Living Daylights', 'http://www.filmtotaal.nl/images/covers/kdlqdvsqiy.jpg', 'James Bond moet zien te voorkomen dat een onbekende scherpschutter de KGB-agent Georgi Koskov van het leven berooft. De mysterieuze schutter blijkt de aantrekkelijke celliste Kara Malovy te zijn. Generaal Koskov vertelt dat de KGB van plan is om moordaans', 'Actie:Avontuur:Muziek:Thriller', '130', 'http://www.filmtotaal.nl/film.php?id=1851', 'RTL7', '6.7', '1444933800'),
(57, 'The Hours', 'http://www.filmtotaal.nl/images/covers/jl28okuvzp.jpg', 'De zwangere Laura Brown plant in 1949 een feest voor haar echtgenoot, en leest tegelijkertijd de roman Mrs. Dalloway van Virginia Woolf. Clarissa Vaughn, een vrouw die in het heden leeft, organiseert een feestje voor haar vriend Richard, een beroemde aute', 'Drama', '114', 'http://www.filmtotaal.nl/film.php?id=7409', 'RTL8', '7.6', '1444933800'),
(58, 'Wild Hogs', 'http://www.filmtotaal.nl/images/covers/1gdlkxq2p2.jpg', 'Vier vrienden in een midlifecrisis, Doug (Tim Allen), Woody (John Travolta), Bobby (Martin Lawrence) en Dudley (William H. Macy), besluiten hun geroutineerde en doorsnee leven een andere draai te geven en beginnen aan een freewheeling trip op de motor. Na', 'Actie:Avontuur:Komedie', '100', 'http://www.filmtotaal.nl/film.php?id=241', 'Veronica', '5.9', '1444933800'),
(59, 'Rescue Dawn', 'http://www.filmtotaal.nl/images/covers/ppzx3bmnr0.jpg', 'RESCUE DAWN is het tweede eerbetoon van Herzog aan de onverwoestbare overlevingsdrang van de tijdens Vietnamoorlog neergehaalde piloot Dieter Dengler die Vietcong-gevangenschap en ondoordringbare jungle moet overwinnen. &lt;br&gt;', 'Actie:Avontuur:Drama:Oorlog', '126', 'http://www.filmtotaal.nl/film.php?id=13301', 'SBS9', '7.4', '1444933800'),
(60, 'Fils de l''&eacute;picier, Le', 'http://www.filmtotaal.nl/images/covers/25ser3wocl.jpg', 'Het is hartje zomer wanneer de dertigjarige Antoine noodgedwongen de stad verruilt voor de rustieke omgeving van zijn geboortedorp. Zijn vader ligt in het ziekenhuis en hoewel Antoine een grondige hekel aan hem heeft, neemt hij toch (vooral voor zijn moed', 'Drama', '96', 'http://www.filmtotaal.nl/film.php?id=14061', 'TV5', '7.1', '1444935720'),
(61, 'One for the Money', 'http://www.filmtotaal.nl/images/covers/nzvwzsz3m8.jpg', 'In One for the Money gaat de net ontslagen Stephanie Plum uit wanhoop werken voor het tweederangs schuldsaneringsbureau van haar neef. Ze komt in bizarre en komische situaties terecht wanneer ze Joe Morelli, de man die vroeger haar hart heeft gebroken, mo', 'Actie:Komedie:Misdaad:Thriller', '91', 'http://www.filmtotaal.nl/film.php?id=20947', 'NET5', '5.3', '1444933800'),
(62, 'The Living Daylights', 'http://www.filmtotaal.nl/images/covers/kdlqdvsqiy.jpg', 'James Bond moet zien te voorkomen dat een onbekende scherpschutter de KGB-agent Georgi Koskov van het leven berooft. De mysterieuze schutter blijkt de aantrekkelijke celliste Kara Malovy te zijn. Generaal Koskov vertelt dat de KGB van plan is om moordaans', 'Actie:Avontuur:Muziek:Thriller', '130', 'http://www.filmtotaal.nl/film.php?id=1851', 'RTL7', '6.7', '1444933800'),
(63, 'The Hours', 'http://www.filmtotaal.nl/images/covers/jl28okuvzp.jpg', 'De zwangere Laura Brown plant in 1949 een feest voor haar echtgenoot, en leest tegelijkertijd de roman Mrs. Dalloway van Virginia Woolf. Clarissa Vaughn, een vrouw die in het heden leeft, organiseert een feestje voor haar vriend Richard, een beroemde aute', 'Drama', '114', 'http://www.filmtotaal.nl/film.php?id=7409', 'RTL8', '7.6', '1444933800'),
(64, 'Wild Hogs', 'http://www.filmtotaal.nl/images/covers/1gdlkxq2p2.jpg', 'Vier vrienden in een midlifecrisis, Doug (Tim Allen), Woody (John Travolta), Bobby (Martin Lawrence) en Dudley (William H. Macy), besluiten hun geroutineerde en doorsnee leven een andere draai te geven en beginnen aan een freewheeling trip op de motor. Na', 'Actie:Avontuur:Komedie', '100', 'http://www.filmtotaal.nl/film.php?id=241', 'Veronica', '5.9', '1444933800'),
(65, 'Rescue Dawn', 'http://www.filmtotaal.nl/images/covers/ppzx3bmnr0.jpg', 'RESCUE DAWN is het tweede eerbetoon van Herzog aan de onverwoestbare overlevingsdrang van de tijdens Vietnamoorlog neergehaalde piloot Dieter Dengler die Vietcong-gevangenschap en ondoordringbare jungle moet overwinnen. &lt;br&gt;', 'Actie:Avontuur:Drama:Oorlog', '126', 'http://www.filmtotaal.nl/film.php?id=13301', 'SBS9', '7.4', '1444933800'),
(66, 'Fils de l''&eacute;picier, Le', 'http://www.filmtotaal.nl/images/covers/25ser3wocl.jpg', 'Het is hartje zomer wanneer de dertigjarige Antoine noodgedwongen de stad verruilt voor de rustieke omgeving van zijn geboortedorp. Zijn vader ligt in het ziekenhuis en hoewel Antoine een grondige hekel aan hem heeft, neemt hij toch (vooral voor zijn moed', 'Drama', '96', 'http://www.filmtotaal.nl/film.php?id=14061', 'TV5', '7.1', '1444935720'),
(67, 'One for the Money', 'http://www.filmtotaal.nl/images/covers/nzvwzsz3m8.jpg', 'In One for the Money gaat de net ontslagen Stephanie Plum uit wanhoop werken voor het tweederangs schuldsaneringsbureau van haar neef. Ze komt in bizarre en komische situaties terecht wanneer ze Joe Morelli, de man die vroeger haar hart heeft gebroken, mo', 'Actie:Komedie:Misdaad:Thriller', '91', 'http://www.filmtotaal.nl/film.php?id=20947', 'NET5', '5.3', '1444933800'),
(68, 'The Living Daylights', 'http://www.filmtotaal.nl/images/covers/kdlqdvsqiy.jpg', 'James Bond moet zien te voorkomen dat een onbekende scherpschutter de KGB-agent Georgi Koskov van het leven berooft. De mysterieuze schutter blijkt de aantrekkelijke celliste Kara Malovy te zijn. Generaal Koskov vertelt dat de KGB van plan is om moordaans', 'Actie:Avontuur:Muziek:Thriller', '130', 'http://www.filmtotaal.nl/film.php?id=1851', 'RTL7', '6.7', '1444933800'),
(69, 'The Hours', 'http://www.filmtotaal.nl/images/covers/jl28okuvzp.jpg', 'De zwangere Laura Brown plant in 1949 een feest voor haar echtgenoot, en leest tegelijkertijd de roman Mrs. Dalloway van Virginia Woolf. Clarissa Vaughn, een vrouw die in het heden leeft, organiseert een feestje voor haar vriend Richard, een beroemde aute', 'Drama', '114', 'http://www.filmtotaal.nl/film.php?id=7409', 'RTL8', '7.6', '1444933800'),
(70, 'Wild Hogs', 'http://www.filmtotaal.nl/images/covers/1gdlkxq2p2.jpg', 'Vier vrienden in een midlifecrisis, Doug (Tim Allen), Woody (John Travolta), Bobby (Martin Lawrence) en Dudley (William H. Macy), besluiten hun geroutineerde en doorsnee leven een andere draai te geven en beginnen aan een freewheeling trip op de motor. Na', 'Actie:Avontuur:Komedie', '100', 'http://www.filmtotaal.nl/film.php?id=241', 'Veronica', '5.9', '1444933800'),
(71, 'Rescue Dawn', 'http://www.filmtotaal.nl/images/covers/ppzx3bmnr0.jpg', 'RESCUE DAWN is het tweede eerbetoon van Herzog aan de onverwoestbare overlevingsdrang van de tijdens Vietnamoorlog neergehaalde piloot Dieter Dengler die Vietcong-gevangenschap en ondoordringbare jungle moet overwinnen. &lt;br&gt;', 'Actie:Avontuur:Drama:Oorlog', '126', 'http://www.filmtotaal.nl/film.php?id=13301', 'SBS9', '7.4', '1444933800'),
(72, 'Fils de l''&eacute;picier, Le', 'http://www.filmtotaal.nl/images/covers/25ser3wocl.jpg', 'Het is hartje zomer wanneer de dertigjarige Antoine noodgedwongen de stad verruilt voor de rustieke omgeving van zijn geboortedorp. Zijn vader ligt in het ziekenhuis en hoewel Antoine een grondige hekel aan hem heeft, neemt hij toch (vooral voor zijn moed', 'Drama', '96', 'http://www.filmtotaal.nl/film.php?id=14061', 'TV5', '7.1', '1444935720'),
(73, 'One for the Money', 'http://www.filmtotaal.nl/images/covers/nzvwzsz3m8.jpg', 'In One for the Money gaat de net ontslagen Stephanie Plum uit wanhoop werken voor het tweederangs schuldsaneringsbureau van haar neef. Ze komt in bizarre en komische situaties terecht wanneer ze Joe Morelli, de man die vroeger haar hart heeft gebroken, mo', 'Actie:Komedie:Misdaad:Thriller', '91', 'http://www.filmtotaal.nl/film.php?id=20947', 'NET5', '5.3', '1444933800'),
(74, 'The Living Daylights', 'http://www.filmtotaal.nl/images/covers/kdlqdvsqiy.jpg', 'James Bond moet zien te voorkomen dat een onbekende scherpschutter de KGB-agent Georgi Koskov van het leven berooft. De mysterieuze schutter blijkt de aantrekkelijke celliste Kara Malovy te zijn. Generaal Koskov vertelt dat de KGB van plan is om moordaans', 'Actie:Avontuur:Muziek:Thriller', '130', 'http://www.filmtotaal.nl/film.php?id=1851', 'RTL7', '6.7', '1444933800'),
(75, 'The Hours', 'http://www.filmtotaal.nl/images/covers/jl28okuvzp.jpg', 'De zwangere Laura Brown plant in 1949 een feest voor haar echtgenoot, en leest tegelijkertijd de roman Mrs. Dalloway van Virginia Woolf. Clarissa Vaughn, een vrouw die in het heden leeft, organiseert een feestje voor haar vriend Richard, een beroemde aute', 'Drama', '114', 'http://www.filmtotaal.nl/film.php?id=7409', 'RTL8', '7.6', '1444933800'),
(76, 'Wild Hogs', 'http://www.filmtotaal.nl/images/covers/1gdlkxq2p2.jpg', 'Vier vrienden in een midlifecrisis, Doug (Tim Allen), Woody (John Travolta), Bobby (Martin Lawrence) en Dudley (William H. Macy), besluiten hun geroutineerde en doorsnee leven een andere draai te geven en beginnen aan een freewheeling trip op de motor. Na', 'Actie:Avontuur:Komedie', '100', 'http://www.filmtotaal.nl/film.php?id=241', 'Veronica', '5.9', '1444933800'),
(77, 'Rescue Dawn', 'http://www.filmtotaal.nl/images/covers/ppzx3bmnr0.jpg', 'RESCUE DAWN is het tweede eerbetoon van Herzog aan de onverwoestbare overlevingsdrang van de tijdens Vietnamoorlog neergehaalde piloot Dieter Dengler die Vietcong-gevangenschap en ondoordringbare jungle moet overwinnen. &lt;br&gt;', 'Actie:Avontuur:Drama:Oorlog', '126', 'http://www.filmtotaal.nl/film.php?id=13301', 'SBS9', '7.4', '1444933800'),
(78, 'Fils de l''&eacute;picier, Le', 'http://www.filmtotaal.nl/images/covers/25ser3wocl.jpg', 'Het is hartje zomer wanneer de dertigjarige Antoine noodgedwongen de stad verruilt voor de rustieke omgeving van zijn geboortedorp. Zijn vader ligt in het ziekenhuis en hoewel Antoine een grondige hekel aan hem heeft, neemt hij toch (vooral voor zijn moed', 'Drama', '96', 'http://www.filmtotaal.nl/film.php?id=14061', 'TV5', '7.1', '1444935720'),
(79, 'One for the Money', 'http://www.filmtotaal.nl/images/covers/nzvwzsz3m8.jpg', 'In One for the Money gaat de net ontslagen Stephanie Plum uit wanhoop werken voor het tweederangs schuldsaneringsbureau van haar neef. Ze komt in bizarre en komische situaties terecht wanneer ze Joe Morelli, de man die vroeger haar hart heeft gebroken, mo', 'Actie:Komedie:Misdaad:Thriller', '91', 'http://www.filmtotaal.nl/film.php?id=20947', 'NET5', '5.3', '1444933800'),
(80, 'The Living Daylights', 'http://www.filmtotaal.nl/images/covers/kdlqdvsqiy.jpg', 'James Bond moet zien te voorkomen dat een onbekende scherpschutter de KGB-agent Georgi Koskov van het leven berooft. De mysterieuze schutter blijkt de aantrekkelijke celliste Kara Malovy te zijn. Generaal Koskov vertelt dat de KGB van plan is om moordaans', 'Actie:Avontuur:Muziek:Thriller', '130', 'http://www.filmtotaal.nl/film.php?id=1851', 'RTL7', '6.7', '1444933800'),
(81, 'The Hours', 'http://www.filmtotaal.nl/images/covers/jl28okuvzp.jpg', 'De zwangere Laura Brown plant in 1949 een feest voor haar echtgenoot, en leest tegelijkertijd de roman Mrs. Dalloway van Virginia Woolf. Clarissa Vaughn, een vrouw die in het heden leeft, organiseert een feestje voor haar vriend Richard, een beroemde aute', 'Drama', '114', 'http://www.filmtotaal.nl/film.php?id=7409', 'RTL8', '7.6', '1444933800'),
(82, 'Wild Hogs', 'http://www.filmtotaal.nl/images/covers/1gdlkxq2p2.jpg', 'Vier vrienden in een midlifecrisis, Doug (Tim Allen), Woody (John Travolta), Bobby (Martin Lawrence) en Dudley (William H. Macy), besluiten hun geroutineerde en doorsnee leven een andere draai te geven en beginnen aan een freewheeling trip op de motor. Na', 'Actie:Avontuur:Komedie', '100', 'http://www.filmtotaal.nl/film.php?id=241', 'Veronica', '5.9', '1444933800'),
(83, 'Rescue Dawn', 'http://www.filmtotaal.nl/images/covers/ppzx3bmnr0.jpg', 'RESCUE DAWN is het tweede eerbetoon van Herzog aan de onverwoestbare overlevingsdrang van de tijdens Vietnamoorlog neergehaalde piloot Dieter Dengler die Vietcong-gevangenschap en ondoordringbare jungle moet overwinnen. &lt;br&gt;', 'Actie:Avontuur:Drama:Oorlog', '126', 'http://www.filmtotaal.nl/film.php?id=13301', 'SBS9', '7.4', '1444933800'),
(84, 'Fils de l''&eacute;picier, Le', 'http://www.filmtotaal.nl/images/covers/25ser3wocl.jpg', 'Het is hartje zomer wanneer de dertigjarige Antoine noodgedwongen de stad verruilt voor de rustieke omgeving van zijn geboortedorp. Zijn vader ligt in het ziekenhuis en hoewel Antoine een grondige hekel aan hem heeft, neemt hij toch (vooral voor zijn moed', 'Drama', '96', 'http://www.filmtotaal.nl/film.php?id=14061', 'TV5', '7.1', '1444935720'),
(85, 'One for the Money', 'http://www.filmtotaal.nl/images/covers/nzvwzsz3m8.jpg', 'In One for the Money gaat de net ontslagen Stephanie Plum uit wanhoop werken voor het tweederangs schuldsaneringsbureau van haar neef. Ze komt in bizarre en komische situaties terecht wanneer ze Joe Morelli, de man die vroeger haar hart heeft gebroken, mo', 'Actie:Komedie:Misdaad:Thriller', '91', 'http://www.filmtotaal.nl/film.php?id=20947', 'NET5', '5.3', '1444933800'),
(86, 'The Living Daylights', 'http://www.filmtotaal.nl/images/covers/kdlqdvsqiy.jpg', 'James Bond moet zien te voorkomen dat een onbekende scherpschutter de KGB-agent Georgi Koskov van het leven berooft. De mysterieuze schutter blijkt de aantrekkelijke celliste Kara Malovy te zijn. Generaal Koskov vertelt dat de KGB van plan is om moordaans', 'Actie:Avontuur:Muziek:Thriller', '130', 'http://www.filmtotaal.nl/film.php?id=1851', 'RTL7', '6.7', '1444933800'),
(87, 'The Hours', 'http://www.filmtotaal.nl/images/covers/jl28okuvzp.jpg', 'De zwangere Laura Brown plant in 1949 een feest voor haar echtgenoot, en leest tegelijkertijd de roman Mrs. Dalloway van Virginia Woolf. Clarissa Vaughn, een vrouw die in het heden leeft, organiseert een feestje voor haar vriend Richard, een beroemde aute', 'Drama', '114', 'http://www.filmtotaal.nl/film.php?id=7409', 'RTL8', '7.6', '1444933800'),
(88, 'Wild Hogs', 'http://www.filmtotaal.nl/images/covers/1gdlkxq2p2.jpg', 'Vier vrienden in een midlifecrisis, Doug (Tim Allen), Woody (John Travolta), Bobby (Martin Lawrence) en Dudley (William H. Macy), besluiten hun geroutineerde en doorsnee leven een andere draai te geven en beginnen aan een freewheeling trip op de motor. Na', 'Actie:Avontuur:Komedie', '100', 'http://www.filmtotaal.nl/film.php?id=241', 'Veronica', '5.9', '1444933800'),
(89, 'Rescue Dawn', 'http://www.filmtotaal.nl/images/covers/ppzx3bmnr0.jpg', 'RESCUE DAWN is het tweede eerbetoon van Herzog aan de onverwoestbare overlevingsdrang van de tijdens Vietnamoorlog neergehaalde piloot Dieter Dengler die Vietcong-gevangenschap en ondoordringbare jungle moet overwinnen. &lt;br&gt;', 'Actie:Avontuur:Drama:Oorlog', '126', 'http://www.filmtotaal.nl/film.php?id=13301', 'SBS9', '7.4', '1444933800'),
(90, 'Fils de l''&eacute;picier, Le', 'http://www.filmtotaal.nl/images/covers/25ser3wocl.jpg', 'Het is hartje zomer wanneer de dertigjarige Antoine noodgedwongen de stad verruilt voor de rustieke omgeving van zijn geboortedorp. Zijn vader ligt in het ziekenhuis en hoewel Antoine een grondige hekel aan hem heeft, neemt hij toch (vooral voor zijn moed', 'Drama', '96', 'http://www.filmtotaal.nl/film.php?id=14061', 'TV5', '7.1', '1444935720'),
(91, 'One for the Money', 'http://www.filmtotaal.nl/images/covers/nzvwzsz3m8.jpg', 'In One for the Money gaat de net ontslagen Stephanie Plum uit wanhoop werken voor het tweederangs schuldsaneringsbureau van haar neef. Ze komt in bizarre en komische situaties terecht wanneer ze Joe Morelli, de man die vroeger haar hart heeft gebroken, mo', 'Actie:Komedie:Misdaad:Thriller', '91', 'http://www.filmtotaal.nl/film.php?id=20947', 'NET5', '5.3', '1444933800'),
(92, 'The Living Daylights', 'http://www.filmtotaal.nl/images/covers/kdlqdvsqiy.jpg', 'James Bond moet zien te voorkomen dat een onbekende scherpschutter de KGB-agent Georgi Koskov van het leven berooft. De mysterieuze schutter blijkt de aantrekkelijke celliste Kara Malovy te zijn. Generaal Koskov vertelt dat de KGB van plan is om moordaans', 'Actie:Avontuur:Muziek:Thriller', '130', 'http://www.filmtotaal.nl/film.php?id=1851', 'RTL7', '6.7', '1444933800'),
(93, 'The Hours', 'http://www.filmtotaal.nl/images/covers/jl28okuvzp.jpg', 'De zwangere Laura Brown plant in 1949 een feest voor haar echtgenoot, en leest tegelijkertijd de roman Mrs. Dalloway van Virginia Woolf. Clarissa Vaughn, een vrouw die in het heden leeft, organiseert een feestje voor haar vriend Richard, een beroemde aute', 'Drama', '114', 'http://www.filmtotaal.nl/film.php?id=7409', 'RTL8', '7.6', '1444933800'),
(94, 'Wild Hogs', 'http://www.filmtotaal.nl/images/covers/1gdlkxq2p2.jpg', 'Vier vrienden in een midlifecrisis, Doug (Tim Allen), Woody (John Travolta), Bobby (Martin Lawrence) en Dudley (William H. Macy), besluiten hun geroutineerde en doorsnee leven een andere draai te geven en beginnen aan een freewheeling trip op de motor. Na', 'Actie:Avontuur:Komedie', '100', 'http://www.filmtotaal.nl/film.php?id=241', 'Veronica', '5.9', '1444933800'),
(95, 'Rescue Dawn', 'http://www.filmtotaal.nl/images/covers/ppzx3bmnr0.jpg', 'RESCUE DAWN is het tweede eerbetoon van Herzog aan de onverwoestbare overlevingsdrang van de tijdens Vietnamoorlog neergehaalde piloot Dieter Dengler die Vietcong-gevangenschap en ondoordringbare jungle moet overwinnen. &lt;br&gt;', 'Actie:Avontuur:Drama:Oorlog', '126', 'http://www.filmtotaal.nl/film.php?id=13301', 'SBS9', '7.4', '1444933800'),
(96, 'Fils de l''&eacute;picier, Le', 'http://www.filmtotaal.nl/images/covers/25ser3wocl.jpg', 'Het is hartje zomer wanneer de dertigjarige Antoine noodgedwongen de stad verruilt voor de rustieke omgeving van zijn geboortedorp. Zijn vader ligt in het ziekenhuis en hoewel Antoine een grondige hekel aan hem heeft, neemt hij toch (vooral voor zijn moed', 'Drama', '96', 'http://www.filmtotaal.nl/film.php?id=14061', 'TV5', '7.1', '1444935720');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `aanbieders`
--
ALTER TABLE `aanbieders`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `bezoekers`
--
ALTER TABLE `bezoekers`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `films`
--
ALTER TABLE `films`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `aanbieders`
--
ALTER TABLE `aanbieders`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1005;
--
-- AUTO_INCREMENT voor een tabel `bezoekers`
--
ALTER TABLE `bezoekers`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1008;
--
-- AUTO_INCREMENT voor een tabel `films`
--
ALTER TABLE `films`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=97;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
