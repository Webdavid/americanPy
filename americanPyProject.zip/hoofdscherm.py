from tkinter import *
import functies

def bezoekerKlik():
    bezoekerButton.destroy()
    aanbiederButton.destroy()

    def show_films(naam):
        aanbiederTitel.destroy();ButtonDennis.destroy();ButtonTarik.destroy();ButtonMitchel.destroy();ButtonRik.destroy();        ButtonDavid.destroy()
        ingevoerde_naam = naam
        kies_aanbieder_query = ('SELECT * FROM aanbieders WHERE aanbieders.naam =%s')
        functies.cursor.execute(kies_aanbieder_query, (ingevoerde_naam,))
        naam = Label(text="U heeft gekozen voor: " + naam)
        naam.grid()
        for row in functies.cursor:
            film = row[3]
            aanbieder_id = row[0]
        film_informatie = ("SELECT * FROM films WHERE titel=%s")
        functies.cursor.execute(film_informatie, (film,))
        film_gegevens = []
        for row in functies.cursor:
            for i in range(0,9):
                film_gegevens.append(row[i])
        if not film_gegevens:
            leeg_label = Label(text="De gekozen aanbieder vertoont momenteel geen film")
            leeg_label.grid()
        else:
            titel_label = Label(text=film_gegevens[1]);synopsis_label = Label(text=film_gegevens[3]);genre_label = Label(text=film_gegevens[4]);duur_label = Label(text=film_gegevens[5]);rating_label = Label(text=film_gegevens[8]);starttijd_label = Label(text=film_gegevens[9]);
            titel_label.grid();synopsis_label.grid();genre_label.grid();duur_label.grid();rating_label.grid();starttijd_label.grid();
            knop = Button(text="Reserveren", command=lambda: reserveer(ingevoerde_naam, film_gegevens[1]))
            knop.grid()
        def reserveer(naam, film):
            def reserveerfunctie():
                bezoeker_naam = bezoeker_naam1.get()
                bezoeker_email = bezoeker_email1.get()
                bezoeker_email_label.destroy();bezoeker_email1.destroy();bezoeker_naam1.destroy();bezoeker_naam_label.destroy();reserveer_button.destroy()
                eticket = bezoeker_naam + film_gegevens[1]
                eticket_ascii = [ord(i) for i in eticket]
                for i in range(len(eticket_ascii)):
                    eticket_ascii[i] += 3
                code = [chr(b) for b in eticket_ascii]
                code = ''.join(code)
                bezoeker_insert = ("INSERT INTO bezoekers (naam, email, aanbiederid, uniekecode) VALUES (%s, %s, %s, %s)")
                functies.cursor.execute(bezoeker_insert, (bezoeker_naam,bezoeker_email, aanbieder_id, code, ))
                functies.connectie_met_mysql.commit()
                UniekeCodeLabel = Label(root, text="Uw unieke code is: " + code)
                UniekeCodeLabel.grid()


            titel_label.destroy();synopsis_label.destroy();genre_label.destroy();duur_label.destroy();rating_label.destroy();starttijd_label.destroy();knop.destroy()
            Nieuw = Label(text="U heeft gereserveerd voor de film " + film + " Van aanbieder " + naam )
            bezoeker_naam_label = Label(text="Uw naam");bezoeker_naam1 = Entry()
            bezoeker_email_label = Label(text="Uw email");bezoeker_email1 = Entry()
            bezoeker_naam_label.grid();bezoeker_naam1.grid();bezoeker_email_label.grid();bezoeker_email1.grid()

            reserveer_button = Button(text="Reserveer", command=reserveerfunctie)
            reserveer_button.grid()
            Nieuw.grid()



        print(film)

        ''' We moeten nog input maken voor de gebruikers voor invoer email enz. Dit gaat gebruikt worden om de qr code te maken. Ook moeten we de films die bezet zijn door aanbieders een keer per dag legen.  Wat gaan we doen met de qr-code?'''


    aanbiederTitel = Label(text="Hier kunt u uw aanbieder kiezen")
    aanbiederTitel.grid(row=0, column=0)
    ButtonDennis = Button(text="Dennis", command= lambda: show_films("Dennis"))
    ButtonTarik = Button(text="Tarik", command= lambda: show_films("Tarik"))
    ButtonMitchel = Button(text="Mitchel", command= lambda: show_films("Mitchell"))
    ButtonDavid = Button(text="David", command= lambda: show_films("David"))
    ButtonRik = Button(text="Rik", command= lambda: show_films("Rik"))
    ButtonDennis.grid(row=0, column=1)
    ButtonTarik.grid(row=0, column=2)
    ButtonMitchel.grid(row=0, column=3)
    ButtonDavid.grid(row=0, column=4)
    ButtonRik.grid(row=0, column=5)

def aanbiederKlik():
    bezoekerButton.destroy()
    aanbiederButton.destroy()
    meldingFoutInlog = Label(text="Foute inlog")


    def log_in():
        NaamOphalen = NaamE.get()
        WachtwoordOphalen = WachtwoordE.get()
        if NaamOphalen in functies.username_wachtwoord:
            if WachtwoordOphalen == functies.username_wachtwoord[NaamOphalen]:
                NaamL.destroy()
                WachtwoordL.destroy()
                NaamE.destroy()
                WachtwoordE.destroy()
                inlogButton.destroy()
                meldingFoutInlog.destroy()


                UsernameL = Label(text="Aanbieder naam is: " + NaamOphalen)
                UsernameL.grid()


                films_query = ("SELECT * FROM films")
                functies.cursor.execute(films_query) # haal films op
                films = []
                # zet films in list
                for row in functies.cursor:
                    films.append(row[1])
                film_keuze = Label(text="Kies een film uit onderstaande lijst: ")
                film_keuze.grid()
                filmlist = Listbox(root)
                for i in range(len(films)):
                    filmlist.insert(i, films[i-1])
                filmlist.grid()
                def keuzeKlik(x):
                    values = [filmlist.get(idx) for idx in filmlist.curselection()]
                    if len(values) == 1:
                        filmlist.destroy()
                        film_keuze.destroy()
                        filmgekozen = Label(text="U heeft " + values[0] + " gekozen")
                        filmgekozen.grid()
                    films_in_gebruik_query = ("SELECT film FROM aanbieders")
                    functies.cursor.execute(films_in_gebruik_query)
                    films_in_gebruik = []
                    for row in functies.cursor:
                        films_in_gebruik.append(row[0])
                    x = 0
                    while values[0] in films_in_gebruik: # controleren of film niet al in gebruik is
                        filmgekozen.destroy()
                        film_in_gebruik_label = Label(text="De film is in gebruik")
                        film_in_gebruik_label.grid()
                        x = x + 1
                        if x == 1:
                            break
                    while values[0] not in films_in_gebruik:
                        maak_bezet_query = ("UPDATE aanbieders SET film=%s WHERE naam=%s")
                        functies.cursor.execute(maak_bezet_query, (values[0], NaamOphalen))
                        functies.connectie_met_mysql.commit()
                        x = x + 1
                        if x == 1:
                            break

                filmlist.bind('<<ListboxSelect>>', keuzeKlik)

                def laat_bezoekers_zien_functie():
                    filmlist.destroy()
                    film_keuze.destroy()
                    UsernameL.destroy()
                    laat_bezoekers_zien_knop.destroy()
                    gebruikers_bij_aanbieder_query = ("SELECT * FROM bezoekers")
                    functies.cursor.execute(gebruikers_bij_aanbieder_query)
                    bezoekerslijst = {}
                    for row in functies.cursor:
                        bezoekernaam = row[1]
                        bezoekerslijst[row[1]] = row[3]

                    aanbieders_query = ("SELECT * FROM aanbieders")
                    functies.cursor.execute(aanbieders_query)
                    aanbiedersidlijst = {}
                    for row in functies.cursor:
                        aanbiedersidlijst[row[1]] = row[0]

                    for i, k in bezoekerslijst.items():
                        naam = i
                        naamid = k

                        for i, k in aanbiedersidlijst.items():
                            if i == NaamOphalen:
                                if k == naamid:
                                    labelBezoekers = Label(root, text=naam)
                                    labelBezoekers.grid()

                laat_bezoekers_zien_knop = Button(text="Laat bezoekers zien", command=laat_bezoekers_zien_functie)
                laat_bezoekers_zien_knop.grid()


            else:
                meldingFoutInlog.grid()



    NaamL = Label(text="Naam:", font=("Helvetica", 28))
    WachtwoordL = Label(text="Wachtwoord:", font=("Helvetica", 28))

    NaamE = Entry()
    WachtwoordE = Entry()



    inlogButton = Button(text="Inloggen", command=log_in, width=10, height=5, bg="green")

    NaamL.grid(row=0, column=0)
    WachtwoordL.grid(row=1, column=0)
    NaamE.grid(row=0, column=1)
    WachtwoordE.grid(row=1, column=1)
    inlogButton.grid(row=2, columnspan=4)

root = Tk()

bezoekerButton = Button(root, text="Bezoeker", command=bezoekerKlik, height=25, width=50, bg="yellow", font=("Helvetica", 20))
aanbiederButton = Button(root, text="Aanbieder", command=aanbiederKlik, height=25, width=50, bg="green", font=("Helvetica", 20))
bezoekerButton.grid(row=0, column=0)
aanbiederButton.grid(row=0, column=1)
root.mainloop()